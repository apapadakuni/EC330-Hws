//Copright Andreas Papadakis apapadak@bu.edu U40766151

#include <vector>
#include <iostream>
#include <fstream>
#include <string>

using namespace std;



void fourA (){
	char U;
	char num;
	string line;
	int sum=0;
	int start; 
	int counter=0; //counting digits after U
	int totalnumber; //number of good BUIDs
	//vector <int> yo;



	ifstream BUID ("BigData.txt");
	if (BUID.is_open())
	{
		getline (BUID, line);
		BUID.close();
	}
	for (long int i=0; i<line.size(); i++){
		U = line[i];	
		bool checkdigit = ('0' <= U) && (U <= '9');

			if (start == 1 && checkdigit == 1){ //so we start counting, and our character is a digit
			//	cout << counter << " ";
				counter ++;
				sum =  (U - '0') + sum;
			}
			if (start == 1 && checkdigit == 0 && counter <8){ //have started counting but our character is not a digit, reset everything
				start = 0;
				counter = 0;
				sum = 0;
			}
			if (counter > 8){ //have started counting and everything went well, except that after our BUID, we got another digit --> reset everything
				start = 0;
				counter = 0;
				sum = 0;
			}
			if (counter == 8 && start == 1 && checkdigit == 0){ //so we counted correctly and it is not a digit after --> got a BUID 
				if (31 <= sum && sum <=68){
					totalnumber ++;			
				}
			//	yo.push_back(sum); 
				start = 0;
				counter = 0;
				sum = 0;
			}
			if (U == 'U'){ //we have found a match
				sum=0;
				counter = 0;
				start = 1; //start starting
			}
	}
	cout << "The number of proper BUIDs is " << totalnumber << endl;
	// cout << "sums are " << endl;

	// for (int i=0; i<yo.size(); i++){
	// 	cout << yo[i] << endl;
	// }
	
}



vector <int> getvecprefix(string P)

{ //this is my computation of my vector
	//for my prefix / pattern P that i will need in my KMP algorithm
	vector <int> result(P.size());
	int m = P.size();
	result[0]=0;
	int index = 0;

	for (int i=1; i<m;){

		if (P[i]==P[index]){
			result[i]= index+1;
			index++;
			i++;

		}
		else {
			if (index !=0){
				index = result[index-1];

			}
			else {
				result[i]=0; 
				i++;
			}		
		}
	}


	return result;
}

bool KMP(string text, string pattern){ //This is my KMP algorithm

	//will return true if pattern exists in text
	vector <int> PRE = getvecprefix(pattern);
	
	int i=0;
	int j=0;
	while (i < text.size() && j < pattern.size()){
		if (text[i] == pattern [j]){
			i++;
			j++;
		}
		else {
			if (j!=0){
				j = PRE[j-1];
			}
			else i++;
		}
	}
	if (j == pattern.size()){
		return true;
	} else return false;
}



void fourB(){
	string Bigdata;
	string potentialword;

	int totalnum=0;
	bool isword;

	ifstream BIG("BigData.txt");
	if (BIG.is_open()){
		getline(BIG,Bigdata);
		BIG.close();
	}
	//cout << Bigdata.size() << endl;
	//basically copied the entire BigData.txt into a string called bigdata, which i use as my text
	//instead of going through bigdata and picking words and seeing if they are in the dictionary
	//i do the opposite: get every word from the dictionary and see if it in BigData

	ifstream DIC("dictionary.txt");
	if (DIC.is_open()){
		while (getline (DIC, potentialword)){
			if (potentialword[0]!='a'){
				isword = KMP(Bigdata, potentialword);
				//if (isword) cout << potentialword << endl; 
				totalnum = totalnum + isword;
			}
		}

		DIC.close();
	}
	cout << "The total number of words in BigData is " << totalnum << endl;
}




string palindrome(string text){ //takes in a text, and returns the biggest palindrome inside it
	int longest = 1;
	int start = 0;
	for (int i=0; i< text.size(); i++){
		int x,y;

		x = i;
		y = i+1;
		while (x>=0 && y < text.size() && text[x] == text[y]){
			if (y - x +1 > longest){
				start = x;
				longest = y - x +1;
			}
			x--;
			y++;
		}
		x = i-1;
		y = i+1;

		while (x>=0 && y < text.size() && text[x]==text[y]){
			if (y-x +1 > longest){
				start = x;
				longest = y - x + 1;
			}
			x--;
			y++;
		}

	}
	string palin = text.substr(start, longest);
	return palin;
}


void fourC(){
	string Bigdata;


	ifstream BIG("BigData.txt");
	if (BIG.is_open()){
		getline(BIG,Bigdata);
		BIG.close();
	} //copied the entire BigData in one string, use as my text in my palindrome function
	
	string sup;
	cout << "The longest palindrome in BigData is :";
	sup = palindrome(Bigdata);
	for (int i=0; i<sup.size(); i++){
		cout << sup[i];
	}
	cout << endl;

}

