//Andreas Papadakis U40776151 apapadak@bu.edu  
//Boxi Huang EC330 U29395110 huangbo@bu.edu


#include "MyBloomFilter.h"
#include <iostream>
#include <vector>
#include <string>


using namespace std;
int hashfunction(string str, int length);


MyBloomFilter:: MyBloomFilter(int length):BloomFilter(length){
    for (int i=0; i<length; i++){
        num.push_back(0);
    }
}


void MyBloomFilter:: insert(string item){
    int length=num.size();
    int position = hashfunction(item, length);
    num[position] = 1;
}


bool MyBloomFilter:: exists(string word){
    int length = num.size();
    int position = hashfunction(word, length);
    if (num[position]== 1){
        return true;
    }
    else return false;
}


string MyBloomFilter:: output(void){
    string out;

    for (int i = 0; i < num.size(); i++) {
        if (num[i]==1){
            out.push_back('1');
        }
        else out.push_back('0');
    }
    return out;
}



int hashfunction(string str, int length) {
    const unsigned int fnv_prime = 0x811C9DC5;
    unsigned int hash = 0;
    unsigned int i = 0;
    unsigned int len = str.length();

    for (i = 0; i < len; i++)
    {
        hash *= fnv_prime;
        hash ^= (str[i]);
    }

    return hash%length;
}



