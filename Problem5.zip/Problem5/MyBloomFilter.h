//Andreas Papadakis U40776151 apapadak@bu.edu
//Boxi Huang EC330 U29395110 huangbo@bu.edu


#include "BloomFilter.h"

#include <string>
#include <vector>



using namespace std;

#ifndef MyBloomFilter_h
#define MyBloomFilter_h

class MyBloomFilter : public BloomFilter{

public:
	MyBloomFilter(int len);
	void insert(string word);
	bool exists(string word);
	string output(void);

private:
	vector <int> num;
};








#endif
